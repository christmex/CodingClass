$(document).ready(function(){
    $('a').on('click', function(e){
        e.preventDefault();
        var href = $(this).attr('href');
        $('#loading').fadeIn(400, function(){
            window.location = href;
        });
    });
});

$(window).load(function(){
    $('#loading').delay(1000).fadeOut(400);
});